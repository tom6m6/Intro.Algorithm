#include <iostream>
#include <ctime>
#include "BST.cpp"
#include <fstream>
#include <vector>
using namespace std;
vector<int> a;
int main() {
    int n;
    cin>>n;
    BST tree;
    ifstream f1("querydata.txt");
    ifstream f2("insertdata.txt");
    for (int i = 0; i < 100000; i++) {
        int t;
        f1>>t;
        tree.insert(t);
    }
    for (int i = 0; i < 10000010; i++) {
        int t;
        f2>>t;
        a.push_back(t);
    }
    f1.close();
    f2.close();
    while (n--) {
        int N;
        cin>>N;
        double start = clock();
        for (int i = 0; i < N; i++) 
            tree.find(a[i]);
        double end = clock();
        double result = (end - start) / CLOCKS_PER_SEC;
        cout<<"�������������Ѵ洢100000��Ԫ�ص�ʱ��"<<endl;
        cout<<"��ѯ"<<N<<"��Ԫ�أ���Ҫ"<<result<<"s"<<endl;
        cout<<endl;
    }
}
