#include <iostream>
#include <cstring>
#include <algorithm>
#include <vector>
using namespace std;

struct Node {
    Node *left;
    Node *right;
    int val;
    Node(int _val):val(_val), left(nullptr), right(nullptr) {}
};

class BST {
public:
    Node *root;//���ڵ�
    Node *prev = nullptr;//Ѱ��ǰ��/���ʱ������ǰ��
    pair<int, int> preSuc;//���ǰ���ͺ��
    BST():root(nullptr){}

    ~BST() {
        destroy(root);
    }

    void destroy(Node *root) {
        if (root) {
            destroy(root->left);
            destroy(root->right);
            delete root;
            root = nullptr;
        }
    }

    bool insert(int _val) {
        if (root == nullptr) {
            root = new Node(_val);
            return true;
        }
        Node *cur = root;
        Node *prev = nullptr;
        while (cur) {
            prev = cur;
            if (cur->val < _val) cur = cur->right;
            else if (cur->val > _val) cur = cur->left;
            else return false;
        }
        cur = new Node(_val);
        if (prev->val < _val) prev->right = cur;
        else prev->left = cur;
        return true;
    }

    Node *find(int _val) {
        Node *cur = root;
        while (cur) {
            if (cur->val < _val) cur = cur->right;
            else if (cur->val > _val) cur = cur->left;
            else return cur;
        }
        return nullptr;
    }

    void preOrder(Node *root) {
        if (root == nullptr) return;
        cout<<root->val<<' ';
        preOrder(root->left);
        preOrder(root->right);
    }

    void inOrder(Node *root) {
        if (root == nullptr) return;
        inOrder(root->left);
        cout<<root->val<<' ';
        inOrder(root->right);
    }
    void postOrder(Node *root) {
        if (root == nullptr) return;
        postOrder(root->left);
        postOrder(root->right);
        cout<<root->val<<' ';
    }
    Node *getMax() {
        Node *cur = root;
        while (cur->right) 
            cur = cur->right;
        return cur;
    }

    Node *getMin() {
        Node *cur = root;
        while (cur->left)
            cur = cur->left;
        return cur;
    }
    //����bool��dfs
    bool getPrev(int _val, Node *cur) {
        if (cur == nullptr) return false;
        if (getPrev(_val, cur->left)) return true;
        if (cur && cur->val == _val) {
            preSuc.first = prev->val;
            return true;
        }
        prev = cur;
        if (getPrev(_val, cur->right)) return true;
        return false;
    }
    //����bool��dfs
    bool getSucc(int _val, Node *cur) {
        if (cur == nullptr) return false;
        if (getSucc(_val, cur->left)) return true;
        if (prev && prev->val == _val) {
            preSuc.second = cur->val;
            return true;
        }
        prev = cur;
        if (getSucc(_val, cur->right)) return true;
        return false;
    }
};

// int main() {
//     string str;
//     BST tree;
//     cin>>str;
//     char *s = const_cast<char*>(str.c_str());//string->char * ������const char *
//     char *delim;
//     delim = strtok(s, ",");
//     while (delim != NULL) {
//         if (*delim != 'n') {
//             int t = atoi(delim);
//             tree.insert(t);
//         }
//         delim = strtok(NULL, ",");
//     }
//     tree.preOrder(tree.root);
//     cout<<endl;
//     cout<<tree.getMin()->val<<endl<<tree.getMax()->val<<endl;
//     int n;
//     cin>>n;
//     while (n--) {
//         int t; cin>>t;
//         if (tree.find(t) == nullptr) cout<<"no"<<endl;
//         else cout<<"yes"<<endl;
//     }
//     int m;
//     cin>>m;
//     while (m--) {
// 		int t; cin>>t;
// 		tree.prev = nullptr;
//         if (tree.getPrev(t, tree.root)) cout<<tree.preSuc.first<<endl;
//         if (tree.getSucc(t, tree.root)) cout<<tree.preSuc.second<<endl;
//     }
//     return 0;
// }
// int main() {
//     string str;
//     BST tree;
//     cin>>str;
//     char *s = const_cast<char*>(str.c_str());//string->char * ������const char *
//     char *delim;
//     delim = strtok(s, ",");
//     while (delim != NULL) {
//         if (*delim != 'n') {
//             int t = atoi(delim);
//             tree.insert(t);
//         }
//         delim = strtok(NULL, ",");
//     }
//     cout<<"���������";
//     tree.preOrder(tree.root);
//     cout<<endl;
//     cout<<"���������";
//     tree.inOrder(tree.root);
//     cout<<endl;
//     cout<<"���������";
//     tree.postOrder(tree.root);
//     cout<<endl;
// }