#include <iostream>
#include <ctime>
#include <random>
#include <fstream>
using namespace std;
int main() {
    default_random_engine e;
    uniform_int_distribution<int> u(1, 2147483647);
    ofstream f1("querydata.txt");
    ofstream f2("insertdata.txt");
    e.seed(time(0));
    for (int i = 0; i < 10000010; i++) {
        f1<<u(e)<<' ';
    }
    for (int i = 0; i < 1000000; i++) {
        f2<<u(e)<<' ';
    }
    f1.close();
    f2.close();
    return 0;
}