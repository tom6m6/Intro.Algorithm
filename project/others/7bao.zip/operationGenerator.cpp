#include <iostream>
#include <string>
#include <vector>
#include <random>
using namespace std;

default_random_engine e;
uniform_int_distribution<int> u(1, 2147483647);
vector<string> methods;

int main() {
    int N;
    cin>>N;
    for (int i = 0; i < N; i++) {
        int op = u(e) % 2; // 0 ��ʾ���룬1 ��ʾ��ѯ
        if (op == 0) {
            methods.push_back("insert");
        } 
        else {
            methods.push_back("query");
        }
    }
}
