#include <iostream>
#include <fstream>
#include <algorithm>
#include <unordered_set>
#include <vector>
#include <cstring>
#include <unordered_map>
#include <sstream>
#include <limits>
#define N 50
double g[N][N];
double dist[N];
bool st[N];
int pre[N];
int chengdu, jiangda;
using namespace std;
int main() {
    unordered_set<string> set;
    vector<string> places;
    unordered_map<string, int> idx;
    ifstream f("data.txt");
    string line;
    while (getline(f, line)) {
        istringstream iss(line);
        string from, to;
        int dist, speed;
        iss >> from>>to>>dist>>speed;
        set.emplace(from);
        set.emplace(to);
    }
    
    places.assign(set.begin(), set.end());
    for (int i = 0; i < places.size(); i++) {
        idx[places[i]] = i;
        if (places[i] == "�ɶ�") chengdu = i;
        if (places[i] == "����") jiangda = i;
    }
    f.clear();
    f.seekg(0, ios::beg);
    
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            g[i][j] = numeric_limits<double>::infinity();
        }
    }

    while (getline(f, line)) {
        istringstream iss(line);
        string from, to;
        double dist, speed;
        iss >> from>>to>>dist>>speed;
        g[idx[from]][idx[to]] = g[idx[to]][idx[from]] = dist / speed;
    }
    
    int n = places.size();

    //dijkstra
    for (int i = 0; i < n; i++) dist[i] = numeric_limits<double>::infinity();
    dist[chengdu] = 0;
    for (int i = 0; i < n - 1; i++) {
        int t = -1;
        for (int j = 0; j < n; j++) {
            int index = idx[places[j]];
            if (!st[index] && (t == -1 || dist[t] > dist[index]))
                t = index;
        }
        //��1-t t-j�ľ���ȥ���� 1-j
        for (int j = 0; j < n; j++) {
            int index = idx[places[j]];
            if (!st[index] && dist[index] > dist[t] + g[t][index]) {
                dist[index] = dist[t] + g[t][index];
                pre[index] = t;
            }
        }
        st[t] = true;
    }
    cout<<"�ܳ���Ϊ��"<<dist[idx[places[jiangda]]]<<endl;
    int t = jiangda;
    cout<<places[t]<<' ';
    while (t != chengdu) {
        cout<<places[pre[t]]<<' ';
        t = pre[t];
    }
}