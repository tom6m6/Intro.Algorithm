#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
using namespace std;
int main() {
    ofstream fout("data.txt");
    srand(time(NULL));
    int s,t,n;
    cin>>s>>t>>n;
    for(int i=0;i<n;i++)fout<<((double)rand()/RAND_MAX * (t - s + 1)+s)<<" ";
    fout.close();
    return 0;
}
