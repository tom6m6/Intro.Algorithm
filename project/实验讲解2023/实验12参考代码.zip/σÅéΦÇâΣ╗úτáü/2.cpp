#include "iostream"
using namespace std;
#define N 34
#define R 6371.004
int main(){
    string cities[N]={"沈阳","长春","哈尔滨","北京","天津","呼和浩特","银川",
                      "太原","石家庄","济南","郑州","西安","武汉","南京","合肥",
                      "上海","长沙","南昌","杭州","福州","广州","台北","海口",
                      "南宁","重庆","昆明","贵阳","成都","兰州","西宁","拉萨",
                      "乌鲁木齐","香港","澳门"};
    double S[N][2]={{123.429092,41.796768},
                    {125.324501,43.886841},
                    {126.642464,45.756966},
                    {116.405289,39.904987},
                    {117.190186,39.125595},
                    {111.751990,40.841490},
                    {106.232480,38.486440},
                    {112.549248,37.857014},
                    {114.502464,38.045475},
                    {117.000923,36.675808},
                    {113.665413,34.757977},
                    {108.948021,34.263161},
                    {114.298569,30.584354},
                    {118.76741,32.041546},
                    {117.283043,31.861191},
                    {121.472641,31.231707},
                    {112.982277,28.19409},
                    {115.892151,28.676493},
                    {120.15358,30.287458},
                    {119.306236,26.075302},
                    {113.28064,23.125177},
                    {121.5200760,25.0307240},
                    {110.199890,20.044220},
                    {108.320007,22.82402},
                    {106.504959,29.533155},
                    {102.71225,25.040609},
                    {106.713478,26.578342},
                    {104.065735,30.659462},
                    {103.834170,36.061380},
                    {101.777820,36.617290},
                    {91.11450,29.644150},
                    {87.616880,43.826630},
                    {114.165460,22.275340},
                    {113.549130,22.198750}};
    bool select[N]; //节点是否被选中
    double minWeight[N];   //到最小生成树的距离
    int prev[N];
    double distance[N][N];

    for (int i = 0; i < N; ++i) {
        minWeight[i] = INT_MAX;
        select[i] = false;
        prev[i] = -1;
    }
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            double C=sin(S[i][1]*M_PI/180)*sin(S[j][1]*M_PI/180)+cos(S[i][1]*M_PI/180)*cos(S[j][1]*M_PI/180)*cos(S[i][0]*M_PI/180-S[j][0]*M_PI/180);
            distance[i][j] = R*acos(C);
        }
    }
    distance[10][29] = 0;
    distance[29][10] = 0;

    double total = 0;
    minWeight[0] = 0;
    for (int i = 0; i < N; ++i) {
        int index = -1;
        double minValue = INT_MAX;
        for (int j = 0; j < N; ++j) {
            if(!select[j] && (index==-1||minWeight[j] < minValue)){
                index = j;
                minValue = minWeight[j];
            }
        }
        if(index == -1){
            return INT_MAX;
        }
        select[index] = true;
        total += minValue;
        for (int j = 0; j < N; ++j) {
            if(!select[j] && distance[index][j] < minWeight[j]){
                minWeight[j] = distance[index][j];
                prev[j] = index;
            }
        }
    }
    double C=sin(S[10][1]*M_PI/180)*sin(S[29][1]*M_PI/180)+cos(S[10][1]*M_PI/180)*cos(S[29][1]*M_PI/180)*cos(S[10][0]*M_PI/180-S[29][0]*M_PI/180);
    double distance1 = R*acos(C);
    for (int i = 33; i >= 0; i--) {
        if(prev[i]==-1){
            continue;
        }
        if(distance[prev[i]][i]==0){
            cout<<cities[i]<<" "<<cities[prev[i]]<<" "<<distance1<<endl;
        } else {
            cout<<cities[i]<<" "<<cities[prev[i]]<<" "<<distance[prev[i]][i]<<endl;
        }
    }

    cout<<endl;
    cout<<"总长度："<<total+distance1<<endl;
}